<!DOCTYPE html>
<html>
	<head>
		<title>Login Page</title>
	</head>
	<body>
		<form method="post" action="logcheck.php">
			<table align="center">
				<tr>
					<td>UserName</td>
					<td>:</td>
					<td><input type="text" name="uname" placeholder="UserName"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td>:</td>
					<td><input type="password" name="password" placeholder="Password"></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><input type="submit" name="submit" value="Login"></td>
				</tr>
			</table>
		</form>
	</body>
</html>